package com.mp2.bhojanam.network;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class APIClient {

    private static final APIInterceptor apiInterceptor = new APIInterceptor("cd97c95154de4df3bff9cb97323dd44c");
    private static final String BASE_URL = "https://eastus.api.cognitive.microsoft.com/face/v1.0/";
    private static Retrofit retrofit = null;
    private static final OkHttpClient okHttpClient = new OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.MINUTES)
            .readTimeout(60,TimeUnit.MINUTES)
            .writeTimeout(60,TimeUnit.MINUTES)
            .addInterceptor(apiInterceptor).build();

    public static Retrofit getClient() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(okHttpClient)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit;
    }

}
