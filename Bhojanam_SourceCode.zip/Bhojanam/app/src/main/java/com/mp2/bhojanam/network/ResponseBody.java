package com.mp2.bhojanam.network;

import com.google.gson.annotations.SerializedName;

public class ResponseBody {
    @SerializedName("persistedFaceId")
    private String persistedFaceId;

    @SerializedName("faceId")
    private String faceId;

    @SerializedName("confidence")
    private double confidence;

    public String getPersistedFaceId() {
        return persistedFaceId;
    }

    public void setPersistedFaceId(String persistedFaceId) {
        this.persistedFaceId = persistedFaceId;
    }

    public double getConfidence() {
        return confidence;
    }

    public void setConfidence(double confidence) {
        this.confidence = confidence;
    }

    public String getFaceId() {
        return faceId;
    }

    public void setFaceId(String faceId) {
        this.faceId = faceId;
    }
}
