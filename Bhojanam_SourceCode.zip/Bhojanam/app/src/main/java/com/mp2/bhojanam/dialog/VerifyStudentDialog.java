package com.mp2.bhojanam.dialog;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.icu.text.SimpleDateFormat;
import android.icu.util.Calendar;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.content.FileProvider;
import androidx.fragment.app.DialogFragment;
import androidx.room.Room;

import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.mp2.bhojanam.BuildConfig;
import com.mp2.bhojanam.R;
import com.mp2.bhojanam.database.MealDatabase;
import com.mp2.bhojanam.database.MealEntity;
import com.mp2.bhojanam.database.StudentEntity;
import com.mp2.bhojanam.database.StudentModel;
import com.mp2.bhojanam.network.APIClient;
import com.mp2.bhojanam.network.BhojanamAPI;
import com.mp2.bhojanam.network.ResponseBody;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.app.Activity.RESULT_OK;

public class VerifyStudentDialog extends DialogFragment {

    public VerifyStudentDialog(StudentModel studentEntity, OnStudentVerifed onStudentVerifed) {
        this.studentEntity = studentEntity;
        this.onStudentVerifed = onStudentVerifed;
    }

    private OnStudentVerifed onStudentVerifed;
    private StudentModel studentEntity;
    private SharedPreferences sharedPreferences;
    private ImageView imgVS, imgSubmit, imgVerify;
    private LinearLayout llImage, llBio;
    private TextView txtName, txtSchool, txtClass, txtVerify;
    private Boolean isImgVerified = false;
    String pictureFilePath = "";
    private ProgressDialog progressDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_verify_student_dialog, container, false);

        sharedPreferences = getActivity().getSharedPreferences(getString(R.string.pref), Context.MODE_PRIVATE);
        imgVS = view.findViewById(R.id.imgVS);
        imgSubmit = view.findViewById(R.id.imgVSSubmit);
        imgVerify = view.findViewById(R.id.imVSVerify);
        llImage = view.findViewById(R.id.llVSImage);
        llBio = view.findViewById(R.id.llVSBiometrics);
        txtName = view.findViewById(R.id.txtVSName);
        txtSchool = view.findViewById(R.id.txtVSSchool);
        txtClass = view.findViewById(R.id.txtVSClass);
        txtVerify = view.findViewById(R.id.txtVSVerify);
        progressDialog = new ProgressDialog(getActivity());

        txtName.setText(studentEntity.getName());
        txtSchool.setText("School : " + sharedPreferences.getString("school", ""));
        txtClass.setText("Class : " + studentEntity.getStudent_class());
        Picasso.get().load(studentEntity.getImage()).error(R.drawable.avatar).into(imgVS);

        llBio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makeErrorToast("Feature Not Developed", null, "");
                llBio.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake));
            }
        });

        llImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*Intent intent=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent,101);*/

                if (!isImgVerified) {
                    Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    cameraIntent.putExtra(MediaStore.EXTRA_FINISH_ON_COMPLETION, true);
                    if (cameraIntent.resolveActivity(getActivity().getPackageManager()) != null) {

                        File pictureFile = null;
                        try {
                            pictureFile = getPictureFile();
                        } catch (IOException ex) {
                            Toast.makeText(getActivity(),
                                    "Photo file can't be created, please try again",
                                    Toast.LENGTH_SHORT).show();
                            return;
                        }
                        if (pictureFile != null) {
                            Uri photoURI = FileProvider.getUriForFile(getActivity(),
                                    BuildConfig.APPLICATION_ID + ".fileprovider",
                                    pictureFile);
                            cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                            startActivityForResult(cameraIntent, 102);
                        }
                    }
                }

            }
        });

        imgSubmit.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.N)
            @Override
            public void onClick(View v) {
                if (!isImgVerified) {
                    makeErrorToast("Please verify image.", null, "");
                    llImage.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake));
                } else {

                    AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
                    dialog.setCancelable(false);
                    dialog.setMessage("Meal Check Verified.");
                    dialog.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            onStudentVerifed.onStudentVerified(studentEntity);
                            dismiss();
                        }
                    });
                    dialog.create();
                    dialog.show();
                }
            }
        });

        return view;
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    private File getPictureFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        String pictureFile = "FACEAPP_" + timeStamp;
        File storageDir = getActivity().getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(pictureFile, ".jpg", storageDir);
        pictureFilePath = image.getAbsolutePath();
        return image;
    }

    public void makeErrorToast(String text, EditText editText, String hint) {
        View view = LayoutInflater.from(getActivity()).inflate(R.layout.toast, null);
        Toast toast = new Toast(getActivity());
        TextView textView = view.findViewById(R.id.toast_text);
        textView.setText(text);
        toast.setView(view);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.show();
        if (editText != null) {
            editText.setText(null);
            editText.setHint(hint);
            editText.setHintTextColor(getResources().getColor(R.color.colorAccent));
            editText.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake));
            editText.clearFocus();
        }
    }


    public interface OnStudentVerifed {
        void onStudentVerified(StudentModel studentEntity);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if (requestCode == 102 && resultCode == RESULT_OK) {
            File imgFile = new File(pictureFilePath);
            if (imgFile.exists()) {
                addToCloudStorage(saveBitmapToFile(imgFile));
            }
        }

        //Verification Success
    }

    private void showDialog(String msg) {
        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setCancelable(false);
        progressDialog.setMessage(msg);
        progressDialog.show();
    }

    private void cancelDialog() {
        progressDialog.dismiss();
    }

    private void addToCloudStorage(File f) {
        showDialog("Verifying Student Image...");
        Uri picUri = Uri.fromFile(f);
        final String cloudFilePath = picUri.getLastPathSegment();

        FirebaseStorage firebaseStorage = FirebaseStorage.getInstance();
        final StorageReference storageRef = firebaseStorage.getReference();
        final StorageReference uploadeRef = storageRef.child(cloudFilePath);

        uploadeRef.putFile(picUri).addOnFailureListener(new OnFailureListener() {
            public void onFailure(@NonNull Exception exception) {
                cancelDialog();
                makeErrorToast("Some error occurred!", null, "");
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                uploadeRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        detectFace(uri.toString());
                    }
                });
            }
        });
    }

    private void detectFace(String url) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("url", url);
            RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), jsonObject.toString());
            Call<List<ResponseBody>> call = APIClient.getClient().create(BhojanamAPI.class).detectFace(body);
            call.enqueue(new Callback<List<ResponseBody>>() {
                @Override
                public void onResponse(Call<List<ResponseBody>> call, Response<List<ResponseBody>> response) {
                    Log.d("hello", "DetectFaceRes" + response.code() + " " + response.message());
                    if (response.code() == 200) {
                        if (response.body().isEmpty()) {
                            cancelDialog();
                            makeErrorToast("No Face detected, please click a clear picture. Make sure the lighting conditions are good.", null, "");
                        } else {
                            verifyUser(response.body().get(0).getFaceId());
                            Log.d("hello", "faceId" + response.body().get(0).getFaceId());
                        }
                    } else {
                        cancelDialog();
                        makeErrorToast("Something went wrong! Please try again.", null, "");
                    }
                }

                @Override
                public void onFailure(Call<List<ResponseBody>> call, Throwable t) {
                    Log.d("hello", "DetectFaceRes" + t.getMessage() + " ");
                    cancelDialog();
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
            cancelDialog();
        }
    }

    private void verifyUser(String faceId) {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("faceId", faceId);
            jsonObject.put("faceListId", "my_face_app");
            jsonObject.put("maxNumOfCandidatesReturned", 1);
            jsonObject.put("mode", "matchPerson");
            RequestBody body = RequestBody.create(MediaType.parse("application/json; charset=utf-8"), jsonObject.toString());
            Call<List<ResponseBody>> call = APIClient.getClient().create(BhojanamAPI.class).verifyUser(body);
            call.enqueue(new Callback<List<ResponseBody>>() {
                @Override
                public void onResponse(Call<List<ResponseBody>> call, Response<List<ResponseBody>> response) {
                    cancelDialog();
                    Log.d("hello", "VerifyRes" + response.code() + " " + response.message());

                    if (response.code() == 200) {
                        if (response.body().isEmpty()) {
                            makeErrorToast("No Student Found! Please Register First!", null, "");
                        } else {

                            if (response.body().get(0).getPersistedFaceId().equals(studentEntity.getFace_id())) {
                                makeErrorToast("Student Image Verified!", null, "");
                                Picasso.get().load(studentEntity.getImage()).error(R.drawable.avatar).into(imgVerify);
                                txtVerify.setText("Student Image Verified");
                                txtVerify.setTextColor(getResources().getColor(R.color.accepted));
                                isImgVerified = true;
                            } else {
                                makeErrorToast("Invalid Student Image!", null, "");
                                txtVerify.setText("Invalid Student Image");
                                txtVerify.setTextColor(getResources().getColor(R.color.design_default_color_error));
                                llImage.startAnimation(AnimationUtils.loadAnimation(getActivity(), R.anim.shake));
                                isImgVerified = false;
                            }
                        }
                    } else {
                        makeErrorToast("Something went wrong! Please try again.", null, "");
                    }

                }

                @Override
                public void onFailure(Call<List<ResponseBody>> call, Throwable t) {
                    Log.d("hello", "VerifyRes" + t.getMessage() + " ");
                }
            });
        } catch (JSONException e) {
            e.printStackTrace();
            cancelDialog();
        }
    }

    public File saveBitmapToFile(File file) {
        try {

            // BitmapFactory options to downsize the image
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            o.inSampleSize = 6;
            // factor of downsizing the image

            FileInputStream inputStream = new FileInputStream(file);
            //Bitmap selectedBitmap = null;
            BitmapFactory.decodeStream(inputStream, null, o);
            inputStream.close();

            // The new size we want to scale to
            final int REQUIRED_SIZE = 75;

            // Find the correct scale value. It should be the power of 2.
            int scale = 1;
            while (o.outWidth / scale / 2 >= REQUIRED_SIZE &&
                    o.outHeight / scale / 2 >= REQUIRED_SIZE) {
                scale *= 2;
            }

            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = scale;
            inputStream = new FileInputStream(file);

            Bitmap selectedBitmap = BitmapFactory.decodeStream(inputStream, null, o2);
            inputStream.close();

            // here i override the original image file
            file.createNewFile();
            FileOutputStream outputStream = new FileOutputStream(file);

            selectedBitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream);

            return file;
        } catch (Exception e) {
            return null;
        }
    }
}
