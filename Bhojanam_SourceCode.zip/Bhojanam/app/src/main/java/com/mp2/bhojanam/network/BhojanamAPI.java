package com.mp2.bhojanam.network;

import java.util.List;

import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface BhojanamAPI {

    @POST("facelists/my_face_app/persistedFaces?detectionModel=detection_02")
    Call<ResponseBody> addFaceToList(@Body RequestBody jsonObject);

    @POST("detect?returnFaceId=true&returnFaceLandmarks=false&recognitionModel=recognition_03&returnRecognitionModel=false&detectionModel=detection_02")
    Call<List<ResponseBody>> detectFace(@Body RequestBody jsonObject);

    @POST("findsimilars")
    Call<List<ResponseBody>> verifyUser(@Body RequestBody jsonObject);

}
