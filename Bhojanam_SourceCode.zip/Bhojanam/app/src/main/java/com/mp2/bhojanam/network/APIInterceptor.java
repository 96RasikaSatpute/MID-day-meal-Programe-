package com.mp2.bhojanam.network;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class APIInterceptor implements Interceptor{

    private String credentials;

    public APIInterceptor(String key) {
        this.credentials = key;
    }

    @Override
    public Response intercept(Interceptor.Chain chain) throws IOException {
        Request.Builder builder = chain.request().newBuilder();
        builder.header("Ocp-Apim-Subscription-Key", credentials);
        builder.header("Content-Type","application/json");
        return chain.proceed(builder.build());
    }

}
